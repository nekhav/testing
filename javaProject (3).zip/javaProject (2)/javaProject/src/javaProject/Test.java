package javaProject;

import java.io.File;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;



public class Test {

	public static void main(String args[]) throws InterruptedException{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\cupcake\\Desktop\\Project1\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://demo.guru99.com/test/newtours/index.php");
		
		String actualTitle = driver.getTitle();
		String expectedTitle = "Welcome: Mercury Tours";
		
		if(actualTitle.contentEquals(expectedTitle))
		{
			System.out.println("Test passed.");
		}
		else
		{
			System.out.println("Test failed.");
		}
		
		driver.close();
	}
	
}
